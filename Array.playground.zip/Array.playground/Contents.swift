import UIKit


var Collect2 : [String] = [ ]
print("You have \(Collect2.count) shells")
if Collect2.isEmpty {
    print("You have no shells")
} else {
    print("SELL THE SHELLS")
}
